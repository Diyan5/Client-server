package registrationApp;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class ViewHandler implements HttpHandler {
    private final String resourcePath;

    public ViewHandler(String resourcePath) {
        this.resourcePath = resourcePath;
    }

    @Override
    public void handle(HttpExchange ex) {
        try (InputStream is = getClass().getResourceAsStream(resourcePath)) {
            if (is == null) {
                respondText(ex, 404, "Not Found");
                return;
            }
            byte[] bytes = is.readAllBytes();
            ex.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
            ex.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(bytes);
            }
        } catch (Exception e) {
            e.printStackTrace();
            respondText(ex, 500, "Internal Server Error");
        }
    }

    private static void respondText(HttpExchange ex, int code, String body) {
        try {
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().add("Content-Type", "text/plain; charset=UTF-8");
            ex.sendResponseHeaders(code, bytes.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
        } catch (Exception ignored) { }
    }
}
