package registrationApp;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class StaticHandler implements HttpHandler {
    private final String baseResourcePath; // пример: "/static/css"

    public StaticHandler(String baseResourcePath) {
        this.baseResourcePath = baseResourcePath;
    }

    @Override
    public void handle(HttpExchange ex) {
        try {
            String uriPath = ex.getRequestURI().getPath(); // напр. /css/index.css
            String fileName = uriPath.substring(uriPath.lastIndexOf('/')); // /index.css
            String decoded = URLDecoder.decode(fileName, StandardCharsets.UTF_8);
            String full = baseResourcePath + decoded; // /static/css/index.css

            try (InputStream is = getClass().getResourceAsStream(full)) {
                if (is == null) {
                    respond404(ex);
                    return;
                }
                byte[] bytes = is.readAllBytes();
                ex.getResponseHeaders().add("Content-Type", contentType(decoded));
                ex.sendResponseHeaders(200, bytes.length);
                try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
            }
        } catch (Exception e) {
            e.printStackTrace();
            respond500(ex);
        }
    }

    private static String contentType(String name) {
        if (name.endsWith(".css")) return "text/css; charset=UTF-8";
        if (name.endsWith(".js")) return "application/javascript; charset=UTF-8";
        if (name.endsWith(".png")) return "image/png";
        if (name.endsWith(".jpg") || name.endsWith(".jpeg")) return "image/jpeg";
        if (name.endsWith(".svg")) return "image/svg+xml";
        return "application/octet-stream";
    }

    private static void respond404(HttpExchange ex) {
        try {
            byte[] b = "Not Found".getBytes(StandardCharsets.UTF_8);
            ex.sendResponseHeaders(404, b.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(b); }
        } catch (Exception ignored) {}
    }

    private static void respond500(HttpExchange ex) {
        try {
            byte[] b = "Internal Server Error".getBytes(StandardCharsets.UTF_8);
            ex.sendResponseHeaders(500, b.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(b); }
        } catch (Exception ignored) {}
    }
}
