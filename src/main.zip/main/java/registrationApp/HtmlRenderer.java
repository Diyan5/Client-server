package registrationApp;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public final class HtmlRenderer {
    private HtmlRenderer(){}

    public static String render(String resourcePath, Map<String, String> vars) throws Exception {
        try (InputStream is = HtmlRenderer.class.getResourceAsStream(resourcePath)) {
            if (is == null) return null;
            String html = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            if (vars != null) {
                for (var e : vars.entrySet()) {
                    String key = "{{" + e.getKey() + "}}";
                    html = html.replace(key, escapeHtml(e.getValue()));
                }
            }
            return html;
        }
    }

    // Проста ескейп функция за безопасност
    public static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                .replace("\"","&quot;").replace("'","&#39;");
    }
}
