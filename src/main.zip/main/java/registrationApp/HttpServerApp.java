package registrationApp;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;

public class HttpServerApp {
    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

        // Home page (твоята HTML страница)
        server.createContext("/", new ViewHandler("/templates/index.html"));

        // Static: /css/* и /images/*
        server.createContext("/css", new StaticHandler("/static/css"));
        server.createContext("/images", new StaticHandler("/static/images"));

//        server.createContext("/", new ViewHandler("/templates/home.html"));
        server.createContext("/login", new AuthHandlers.LoginHandler());
        server.createContext("/register", new AuthHandlers.RegisterHandler());

        server.createContext("/home", new HttpHandler() {
            @Override
            public void handle(HttpExchange ex) {
                try {
                    var session = Sessions.getOrCreate(ex);
                    if (session.userId == null) {
                        HttpUtil.redirect(ex, "/login");
                        return;
                    }
                    Map<String,String> vars = new HashMap<>();
                    vars.put("username", "demo@user.com"); // TODO: вземи от БД по userId
                    String html = HtmlRenderer.render("/views/home.html", vars);
                    byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
                    ex.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
                    ex.sendResponseHeaders(200, bytes.length);
                    ex.getResponseBody().write(bytes);
                    ex.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });



        server.setExecutor(Executors.newFixedThreadPool(16));
        server.start();
        System.out.println("HTTP server started on http://localhost:8080");
    }
}
