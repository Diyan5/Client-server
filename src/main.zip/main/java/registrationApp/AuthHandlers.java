package registrationApp;


import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static registrationApp.HttpUtil.*;


public final class AuthHandlers {
    private AuthHandlers(){}

    // GET -> login.html (инжектира CSRF), POST -> проверява креденшъли
    public static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) {
            try {
                if (ex.getRequestMethod().equalsIgnoreCase("GET")) {
                    renderLogin(ex, "");
                    return;
                }
                if (ex.getRequestMethod().equalsIgnoreCase("POST")) {
                    var session = Sessions.getOrCreate(ex);
                    String body = readBody(ex);
                    Map<String,String> form = parseFormUrlEncoded(body);

                    String csrf = form.getOrDefault("csrf", "");
                    String email = form.getOrDefault("email", "").trim();
                    String password = form.getOrDefault("password", "");
                    String captcha = form.getOrDefault("captcha", "");

                    // CSRF
                    if (!Sessions.checkCsrf(session, csrf)) {
                        renderLogin(ex, "Invalid request.");
                        return;
                    }
                    // Captcha
                    if (session.captchaExpected == null || !session.captchaExpected.equalsIgnoreCase(captcha)) {
                        sleep(300);
                        renderLogin(ex, "Invalid credentials."); // умишлено общо
                        return;
                    }

                    // TODO: userDao.findByEmail(email)
                    // TODO: verify password hash
                    boolean ok = false; // <-- замени с реална проверка
                    if (!ok) {
                        sleep(300);
                        renderLogin(ex, "Invalid credentials.");
                        return;
                    }

                    // success
                    session.userId = 1L; // TODO: real user id
                    redirect(ex, "/home");
                    return;
                }

                ex.sendResponseHeaders(405, -1);
            } catch (Exception e) {
                e.printStackTrace();
                try { ex.sendResponseHeaders(500, -1); } catch (Exception ignored) {}
            }
        }

        private void renderLogin(HttpExchange ex, String error) throws Exception {
            var s = Sessions.getOrCreate(ex);
            Map<String,String> vars = new HashMap<>();
            vars.put("csrf", s.csrf);
            vars.put("error", error == null ? "" : error);
            String html = HtmlRenderer.render("/views/login.html", vars);
            byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            ex.sendResponseHeaders(200, bytes.length);
            ex.getResponseBody().write(bytes);
            ex.close();
        }
    }

    // GET -> register.html, POST -> валидация + insert + redirect /login
    public static class RegisterHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) {
            try {
                if (ex.getRequestMethod().equalsIgnoreCase("GET")) {
                    renderRegister(ex, "");
                    return;
                }
                if (ex.getRequestMethod().equalsIgnoreCase("POST")) {
                    var session = Sessions.getOrCreate(ex);
                    String body = readBody(ex);
                    Map<String,String> form = parseFormUrlEncoded(body);

                    String csrf = form.getOrDefault("csrf", "");
                    String username = form.getOrDefault("username", "").trim();
                    String firstName = form.getOrDefault("firstName", "").trim();
                    String lastName  = form.getOrDefault("lastName", "").trim();
                    String email     = form.getOrDefault("email", "").trim();
                    String pass      = form.getOrDefault("password", "");
                    String conf      = form.getOrDefault("confirmPassword", "");
                    String captcha   = form.getOrDefault("captcha", "");

                    if (!Sessions.checkCsrf(session, csrf)) {
                        renderRegister(ex, "Invalid request.");
                        return;
                    }
                    // TODO: Validators for username/first/last/email/password
                    if (!pass.equals(conf)) {
                        renderRegister(ex, "Invalid input. Please try again.");
                        return;
                    }
                    if (session.captchaExpected == null || !session.captchaExpected.equalsIgnoreCase(captcha)) {
                        renderRegister(ex, "Invalid input. Please try again.");
                        return;
                    }

                    // TODO: if email exists -> refuse with same generic error
                    // TODO: hash password + salt, insert user via UserDao

                    // success -> към login
                    redirect(ex, "/login?registered=1");
                    return;
                }

                ex.sendResponseHeaders(405, -1);
            } catch (Exception e) {
                e.printStackTrace();
                try { ex.sendResponseHeaders(500, -1); } catch (Exception ignored) {}
            }
        }

        private void renderRegister(HttpExchange ex, String error) throws Exception {
            var s = Sessions.getOrCreate(ex);
            Map<String,String> vars = new HashMap<>();
            vars.put("csrf", s.csrf);
            vars.put("error", error == null ? "" : error);
            String html = HtmlRenderer.render("/views/register.html", vars);
            byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            ex.sendResponseHeaders(200, bytes.length);
            ex.getResponseBody().write(bytes);
            ex.close();
        }
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
