package registrationApp;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.security.SecureRandom;

public class CaptchaService {
    private static final String ALPH = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom RAND = new SecureRandom();

    public static Captcha generate() throws Exception {
        String text = randomText(5);
        BufferedImage img = new BufferedImage(140, 48, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 140, 48);

        // анти-алиасинг
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // шум
        g.setColor(new Color(220,220,220));
        for (int i=0;i<8;i++){
            int x1 = RAND.nextInt(140), y1 = RAND.nextInt(48);
            int x2 = RAND.nextInt(140), y2 = RAND.nextInt(48);
            g.drawLine(x1,y1,x2,y2);
        }

        // текст
        g.setFont(new Font("SansSerif", Font.BOLD, 28));
        g.setColor(Color.BLACK);
        g.drawString(text, 18, 33);

        g.dispose();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "png", baos);
        return new Captcha(text, baos.toByteArray());
    }

    private static String randomText(int len) {
        StringBuilder sb = new StringBuilder(len);
        for (int i=0;i<len;i++) sb.append(ALPH.charAt(RAND.nextInt(ALPH.length())));
        return sb.toString();
    }

    public record Captcha(String text, byte[] png) {}
}
