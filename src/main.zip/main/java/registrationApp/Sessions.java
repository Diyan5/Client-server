package registrationApp;

import com.sun.net.httpserver.HttpExchange;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;

public final class Sessions {
    private static final Map<String, SessionData> SESSIONS = new HashMap<>();
    private static final SecureRandom RAND = new SecureRandom();
    private static final int TTL_SECONDS = 30 * 60;

    private Sessions(){}

    public static SessionData getOrCreate(HttpExchange ex) {
        String id = getCookie(ex, "SESSIONID");
        SessionData data = (id != null) ? SESSIONS.get(id) : null;
        if (data != null && data.expiresAt.isAfter(Instant.now())) {
            data.expiresAt = Instant.now().plusSeconds(TTL_SECONDS);
            return data;
        }
        // нова сесия
        String newId = randomId(32);
        SessionData fresh = new SessionData();
        fresh.id = newId;
        fresh.csrf = randomId(16);
        fresh.expiresAt = Instant.now().plusSeconds(TTL_SECONDS);
        SESSIONS.put(newId, fresh);
        setCookie(ex, "SESSIONID", newId, true);
        return fresh;
    }

    public static void invalidate(HttpExchange ex) {
        String id = getCookie(ex, "SESSIONID");
        if (id != null) SESSIONS.remove(id);
        setCookie(ex, "SESSIONID", "", true, 0);
    }

    public static boolean checkCsrf(SessionData s, String token) {
        return s != null && s.csrf != null && s.csrf.equals(token);
    }

    public static String getCookie(HttpExchange ex, String name) {
        List<String> cookies = ex.getRequestHeaders().get("Cookie");
        if (cookies == null) return null;
        for (String header : cookies) {
            String[] parts = header.split(";");
            for (String part : parts) {
                String[] nv = part.trim().split("=", 2);
                if (nv.length == 2 && nv[0].equals(name)) return nv[1];
            }
        }
        return null;
    }

    public static void setCookie(HttpExchange ex, String name, String value, boolean httpOnly) {
        setCookie(ex, name, value, httpOnly, TTL_SECONDS);
    }

    public static void setCookie(HttpExchange ex, String name, String value, boolean httpOnly, int maxAgeSeconds) {
        StringBuilder sb = new StringBuilder();
        sb.append(name).append("=").append(value).append("; Path=/; SameSite=Lax");
        if (httpOnly) sb.append("; HttpOnly");
        if (maxAgeSeconds >= 0) sb.append("; Max-Age=").append(maxAgeSeconds);
        ex.getResponseHeaders().add("Set-Cookie", sb.toString());
    }

    private static String randomId(int bytes) {
        byte[] arr = new byte[bytes];
        RAND.nextBytes(arr);
        StringBuilder hex = new StringBuilder(arr.length * 2);
        for (byte b : arr) hex.append(String.format("%02x", b));
        return hex.toString();
    }

    public static final class SessionData {
        public String id;
        public String csrf;
        public String captchaExpected; // за /captcha.png
        public Long userId;            // ще се ползва след login
        public Instant expiresAt;
    }
}
