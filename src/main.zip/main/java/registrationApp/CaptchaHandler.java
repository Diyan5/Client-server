package registrationApp;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.OutputStream;

public class CaptchaHandler implements HttpHandler {
    @Override
    public void handle(HttpExchange ex) {
        try {
            var session = Sessions.getOrCreate(ex);
            var cap = CaptchaService.generate();
            session.captchaExpected = cap.text();

            ex.getResponseHeaders().set("Content-Type", "image/png");
            ex.getResponseHeaders().set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
            ex.sendResponseHeaders(200, cap.png().length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(cap.png());
            }
        } catch (Exception e) {
            e.printStackTrace();
            try { ex.sendResponseHeaders(500, -1); } catch (Exception ignored) {}
        }
    }
}
